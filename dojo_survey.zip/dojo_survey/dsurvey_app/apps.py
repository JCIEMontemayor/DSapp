from django.apps import AppConfig


class DsurveyAppConfig(AppConfig):
    name = 'dsurvey_app'
